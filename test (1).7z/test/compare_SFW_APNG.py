# -*- coding: utf-8 -*-
"""
Created on Sat Jun  6 14:41:58 2020

@author: KalaN
"""
from settings import *
import os
import pyodbc
from pathlib import Path
import pandas as pd
pd.options.display.max_colwidth = 500
pd.set_option('display.max_columns', None)
#pd.options.mode.chained_assignment = None


class compare:
    
    def __init__(self,df1,df2,index,tol,table):
        self.df1=df1
        self.df2=df2
        self.index=index
        self.tol=tol
        self.table=table

    
    # Helper method to remove spaces
    def trim_all_columns(self,df):
        """
        Trim whitespace from ends of each value across all series in dataframe
        """
        trim_strings = lambda x: x.strip() if isinstance(x, str) else x
        return df.applymap(trim_strings)

    def get_col_widths(self,dataframe):
        # First we find the maximum length of the index column   
        idx_max = max([len(str(s))*1.5 for s in dataframe.index.values] + [len(str(dataframe.index.name))])
        #print(dataframe.index)
        # Then, we concatenate this to the max of the lengths of column name and its values for each column, left to right
        return [idx_max] + [max([len(str(s))+6 for s in dataframe[col].values] + [len(col)+6]) for col in dataframe.columns]    
    
    # This would clean the Dataframes for spaces, Nulls
    def clean_data(self,df1,df2):        
        df1 = df1.fillna('')
        df2 = df2.fillna('')
        df1 = self.trim_all_columns(df1)
        df2 = self.trim_all_columns(df2)
        return(df1,df2)
    
    # This method would help in indetifying column value differences in the 2 Dataframes
    def report_diff(self,x):
        if x[0]==x[1]:
            return x[0].__str__()
        elif pd.isnull(x[0]) and pd.isnull(x[1]):
            return 'NA'
        elif pd.isnull(x[0]) and ~pd.isnull(x[1]):
            return '{} ---> {}'.format('NA',x[1])
        elif ~pd.isnull(x[0]) and pd.isnull(x[1]):
            return '{} ---> {}'.format(x[0],'NA')
        elif (isinstance(x[0], float)==True) and (isinstance(x[1], float)==True):
            if abs(x[0]-x[1])<tol:
                return '{} almost {}'.format(*x)
            else:
                return '{} ---> {}'.format(*x)
        else:
            return '{} ---> {}'.format(*x)
    
    # This would give the rows common in both dataframes and rows unique to each dataframe    
    def stats(self,df1,df2):
        # IN Old , NOT in New
        in_1_not_2=df1[~df1['unique_row_key'].isin(df2['unique_row_key'])]
        
        # IN New , NOT in Old
        in_2_not_1=df2[~df2['unique_row_key'].isin(df1['unique_row_key'])]
        
        # Count of Rows compared
        in_both_1=df1[df1['unique_row_key'].isin(df2['unique_row_key'])]
        in_both_2=df2[df2['unique_row_key'].isin(df1['unique_row_key'])]

        return(in_1_not_2,in_2_not_1,in_both_1,in_both_2)          
    
    # this would give a dataframe with columns that differ in the 2 Dataframes, with differences count of each column
    def difference_count(self,diff_output,in_both_1,in_both_2):
        # pass
        diff_count = pd.DataFrame()
        for col in diff_output:
            count = diff_output[col].str.count("--->").sum()
            if (count > 0):
                diff_count = diff_count.append({'Field':col,'Differences Count':count},ignore_index=True)

         ## if diff_count blank, it means no diff within acceptable tolerance, so add an if clause before returning diff_count
        if len(diff_count) != 0:       
            diff_count.sort_values(by='Differences Count',ascending=False,inplace=True)
            diff_count['Percent Difference']=round(diff_count['Differences Count']/(min(in_both_1,in_both_2))*100,7)
        #print(diff_count)

        
        return(diff_count)
    
    # This would write the differences in the 2 dataframes into an excel file
    def report(self,diff_output,diff_count,all_column_names,sheetname):
        #Misc='Test'
        dest_file_name=f'C:\\Users\kalan\\Documents\\jupiter_nb\\{sheetname}.xlsx'
        #dest_file_name=r"C:\jupiter_nb\Misc.xlsx"
        my_file = Path(dest_file_name)
        if my_file.is_file():
            os.remove(dest_file_name)
        
        writer = pd.ExcelWriter(dest_file_name)
        diff_output.to_excel(writer,'diff_data')
        #print(diff_count)
        #print(type(diff_count))
        if len(diff_count)!=0:
            diff_count.to_excel(writer,'diff_stats',index=False)
        
        workbook  = writer.book
        abc = workbook.add_format({'bg_color': 'cyan'})
        efg = workbook.add_format({'bg_color': 'gray'})
        worksheet = writer.sheets['diff_data']
        for i, width in enumerate(self.get_col_widths(diff_output)):
            worksheet.set_column(i, i, width)
        worksheet.conditional_format(1, 1, diff_output.shape[0], len(all_column_names)-1,
                                    {'type': 'text','criteria': 'containing','value': 'almost',
                                    'format': efg})
        worksheet.conditional_format(1, 1, diff_output.shape[0], len(all_column_names)-1,
                                    {'type': 'text','criteria': 'containing','value': '---',
                                    'format': abc})
        if len(diff_count)!=0:
            worksheet = writer.sheets['diff_stats']
            for i, width in enumerate(self.get_col_widths(diff_count)):
                worksheet.set_column(i, i, width)
                
        writer.save()
     
    # This is the main method that would take 2 Pandas dataframes as inputs, find the differences column-wise for
    # each row if exists in both Dataframes by joining on a unique key being passed as input
        
    def compare_data(self):
        print(f'Unique key used for comparison is {index}')



        #### only for SFW exe testing, drop column SessionID
        df1.drop(columns='SessionID',inplace=True)
        df2.drop(columns='SessionID',inplace=True)


        self.clean_data(df1,df2)
        
        all_column_names=df1.columns.tolist()
        
        df1['version'] = "old"
        df2['version'] = "new"
        
        unique_key = index
#
        df1["unique_row_key"],df2["unique_row_key"]='',''
        for uniq in unique_key:
            df1["unique_row_key"]= df1["unique_row_key"].map(str)+df1[uniq].map(str)+"-"
            df2["unique_row_key"]= df2["unique_row_key"].map(str)+df2[uniq].map(str)+"-"
        #print(df1)


        orig_count_1, orig_count_2 = len(df1), len(df2)
        unique_count_1, unique_count_2 = df1['unique_row_key'].nunique(), df2['unique_row_key'].nunique()



        if orig_count_1 != unique_count_1:
            print('First DataSet does not have Unique Key')
            if orig_count_2 != unique_count_2:
                print('Second DataSet does not have Unique Key')
            return

        
        if orig_count_2 != unique_count_2:
            print('Second DataSet does not have Unique Key')
            return


        # print('TEST',+ orig_count_1,orig_count_2,unique_count_1,unique_count_2)
        print(f'Dataset1 rows {orig_count_1} Dateset1 unique rows {unique_count_1}')
        print(f'Dataset2 rows {orig_count_2} Dateset2 unique rows {unique_count_2}')

        full_set = pd.concat([df1,df2],ignore_index=True)

        #print('full set is {}'.format(full_set))

        changes = full_set.drop_duplicates(subset=all_column_names,keep='first')

        #print('changes are {}'.format(changes))
        
        dupe_rows = changes.set_index('unique_row_key')

        #print('dupe rows {}'.format(dupe_rows))


        dupe_rows=dupe_rows.index[dupe_rows.index.duplicated()].unique()

        #print('dupe rows {}'.format(dupe_rows))

        if len(dupe_rows) ==0 :
            print(f'Both DataSets {self.table} Identical')
            return

        dupes = changes[changes["unique_row_key"].isin(dupe_rows)]
        
        #print('dupes {}'.format(dupes))


        change_df1 = dupes[(dupes["version"] == "old")]
        change_df2 = dupes[(dupes["version"] == "new")]

        change_df1 = change_df1.drop(['version'], axis=1)
        change_df2 = change_df2.drop(['version'],axis=1)
        change_df1.set_index('unique_row_key',inplace=True)
        change_df2.set_index('unique_row_key',inplace=True)
        
        
        diff_concat = pd.concat(
        [change_df1, change_df2], 
        axis='columns', 
        keys=['change_df1', 'change_df2'],
        join='inner'
        )


        
        diff_concat = diff_concat.swaplevel(axis='columns')[change_df1.columns[0:]]

        #print('diff concat',diff_concat)

        diff_output=diff_concat.groupby(level=0, axis=1).apply(lambda frame: frame.apply(self.report_diff, axis=1))


        in_1_not_2,in_2_not_1,in_both_1,in_both_2 = self.stats(df1,df2)

        print(in_1_not_2.shape[0],in_2_not_1.shape[0],min(in_both_1.shape[0],in_both_2.shape[0]))  
        
        diff_count=self.difference_count(diff_output,in_both_1.shape[0],in_both_2.shape[0])

        if len(diff_count) ==0 :
            print(f'Both DataSets {self.table} Identical with the tolerance given')
            return


        col_order = diff_count['Field']
        col_order = col_order.tolist()
        new_cols = change_df1.columns[:].tolist()
        columns = list(set(new_cols)-set(col_order)-set(unique_key))
        reordered = unique_key+col_order+columns
        diff_output=diff_output[reordered]


        self.report(in_1_not_2,diff_count='',all_column_names=all_column_names,sheetname='APNG_'+f'{self.table}'+'_MissingIn2ndDataSet')
        self.report(in_2_not_1,diff_count='',all_column_names=all_column_names,sheetname='APNG_'+f'{self.table}'+'_MissingIn1stDataSet')
        #self.report(in_both_1,diff_count='',all_column_names=all_column_names,sheetname='CommonInBothDataSet')
        self.report(diff_output,diff_count,all_column_names,'APNG_'+f'{self.table}'+'_differences')
        
        
        #return(diff_output)

def data_source(table,test_deals,*year):

    if len(year)!=1:
        period=','.join([x for x in year])
    else:
        period = year[0]
    
    deal_list_1=[x.strip() for x in test_deals[0]]
    
    deal_list_str=','.join(["'"+x+"'" for x in deal_list_1])
    
    cnx_first = pyodbc.connect(cnx_sfw)
    cnx_second = pyodbc.connect(cnx_sfw)

    sql_first=f"""
    SELECT t.*
    FROM [Deal_Guard_QA].[dbo].{table} t with (nolock)
    JOIN  [Deal_Guard_QA].[dbo].SfwDataParserSummary s with (nolock)
    ON t.SessionID = s.SessionID and t.dealid = s.dealid
    WHERE (s.PublishDate >= '2022-04-13 17:37:33.000')
    and s.Comment like '%SFW ApNg Publish%'
    and s.SfwBuild = '51' and s.SfwVersion = '21.11.130153913' -- Prod exe
    AND t.period in ({period})
    AND t.dealid in ({deal_list_str})
    """

    sql_second=f"""
    SELECT t.*
    FROM [Deal_Guard_QA].[dbo].{table} t with (nolock)
    JOIN  [Deal_Guard_QA].[dbo].SfwDataParserSummary s with (nolock)
    ON t.SessionID = s.SessionID and t.dealid = s.dealid
    WHERE (s.PublishDate >= '2022-04-13 08:34:01.000' and s.PublishDate <= '2022-04-13 12:36:54.000') -- April 2022 hotfix
    and s.Comment like '%SFW ApNg Publish%'
    and s.SfwBuild = '59' and s.SfwVersion = '21.11.13866857' ---- April 2022 Hotfix
    AND t.period in ({period})
    AND t.dealid in ({deal_list_str})
    """

    df_first = pd.read_sql(sql_first, con=cnx_first)
    df_second = pd.read_sql(sql_second, con=cnx_second)

    return(df_first,df_second)


# For CSV/Excel comparisons ##########################
######################################################################################################################################
# df1=pd.read_csv('C://Users//kalan//Documents/New Text Document_1.csv')
# df2=pd.read_csv('C://Users//kalan//Documents/New Text Document_2.csv')


# For SQL Tables comparison ONLY #######################
#######################################################################################################################################
#test_deals = pd.read_csv('C://Users//kalan//Documents/APNG.txt',header=None)
test_deals = pd.read_csv('C://Users//kalan//Documents/APNG_1.txt',header=None)

# Give Table Name, CSV test_deals with SFW Deal IDs and Period for comparison as below
# df1,df2=data_source('TrancheAnalytics',test_deals,'202008')
#print(df1)

'''
Choose which tables need to be compared or give all tables with their Unique Keys as below
'''
### SINGLE TABLE
dict_compare = {'DealStaticPerf':['DealID']}

### ALL TABLES
# dict_compare = {'TrancheAnalytics':['DealID','TrancheNumber','Scenario'],'DealStaticPerf':['DealID'],'PoolHistory':['DealID','PoolIndex','HistoryPeriod'],\
#      'TriggerStaticPerf':['DealID','SubTriggerID'],'TrancheStatic':['DealID','TrancheNumber'],'TranchePerf':['DealID','TrancheNumber'],'PoolStatistics':['DealID','PoolNumber'],\
#          'AccountStaticPerf':['DealID','AccountPosition'],'PoolStaticPerf':['DealID','PoolNumber'],'UserVar':['DealID','Name']}

tol=0.0001

period = '202203'


for key,value in dict_compare.items():
    #print(key)
    index = value
    #print(value)
    df1,df2=data_source(key,test_deals,period)
    key = compare(df1, df2, index, tol,key)
    key.compare_data()




''' Uncomment this for individual Class instance creation

index = ['DealID','TrancheNumber','Scenario']
#index = 'DealID'
tol=0.0001
a1 = compare(df1, df2, index, tol)

a1.compare_data()
'''
#df1
#df2
