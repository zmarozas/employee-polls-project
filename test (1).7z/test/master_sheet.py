import glob
import os
from pathlib import Path
import time
import pandas as pd


start_time = time.time()

#os.getcwd()
#os.chdir('C:/jupiter_nb/Oct_2020/APNG/')
#os.getcwd()
os.chdir('C:/Users/kalan/Documents/jupiter_nb/')

def get_col_widths(dataframe):
    # First we find the maximum length of the index column   
    idx_max = max([len(str(s)) for s in dataframe.index.values] + [len(str(dataframe.index.name))])
    # Then, we concatenate this to the max of the lengths of column name and its values for each column, left to right
    return [idx_max] + [max([len(str(s)) for s in dataframe[col].values] + [len(col)]) for col in dataframe.columns]


dest_file_name=r"C:\Users\kalan\Documents\jupiter_nb\Master.xlsx"
my_file = Path(dest_file_name)
if my_file.is_file():
    os.remove(dest_file_name)
a=0

files = [f for f in os.listdir("C:\\Users\kalan\Documents\jupiter_nb\\") if 'difference' in f]
#files = [f for f in os.listdir("C:\\jupiter_nb\\Oct_2020\\APNG") if 'difference' in f]
print(files)
with pd.ExcelWriter(dest_file_name) as writer:
    #for f in glob.glob(".\*.xlsx"):
    for f in files:
        #For APNG        
        a=f.split('_')[1]
        #for AP
        # a=f.split('_')[0]
        print(a)
        df = pd.read_excel(f,sheet_name='diff_stats',engine='openpyxl')
        print(df)
    
        df.to_excel(writer, sheet_name=f'diff_stats_{a}')
        idx_max = max([len(str(s)) for s in df.index.values] + [len(str(df.index.name))])
        #print([idx_max] + [max([len(str(s)) for s in df[col].values] + [len(col)]) for col in df.columns])
        worksheet = writer.sheets[f'diff_stats_{a}']
        
        for i, width in enumerate(get_col_widths(df)):
            worksheet.set_column(i, i, width)
        worksheet.conditional_format('D1:D1112', {'type': '3_color_scale',
                                         'min_value': 0,
                                         'max_value': 20,
                                         'min_color': "green",
                                         'mid_color': "yellow",
                                         'max_color': "red",
                                         'min_type': "num",
                                         'max_type': "num"})
    writer.save()

end_time = time.time()-start_time
print(f'Script too {round(end_time,2)} seconds')

print(files)