# CS-Structured-DDT-SFWCompare

During SFW exe testing, we use these AP and APNG compare scripts to validate the new exe results with Prod exe
